﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    class CurrentAccount
    {
        public class Account : CurrentAccount
        {
            //Properties
            public string InterestRate { get; set; }
        }

       
static void Main()
        {


        }
        }
    }


