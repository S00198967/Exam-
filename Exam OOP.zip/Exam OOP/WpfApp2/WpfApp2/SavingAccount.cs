﻿namespace WpfApp2
{
    internal class SavingAccount
    {
    }
}