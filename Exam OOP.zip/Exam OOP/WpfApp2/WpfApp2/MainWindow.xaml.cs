﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BthDelete_Click(object sender, RoutedEventArgs e)
        {
            

        }

            //Method to update the listbox with the details of the list passed to it
            private void UpdateListBox(List<Account> Employee)
            {
                Employee.Sort();//sorts the list using the CompareTo method in the class
             



            }
        }
    }
    
