﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    class SavingsAccount
    {
        public class Account : SavingsAccount
        {
            //Properties
            public string InterestRate { get; set; } 

           

        }
    }
}

